<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>

    <!-- Fonts -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css" integrity="sha384-XdYbMnZ/QjLh6iI4ogqCTaIjrFk87ip+ekIjefZch0Y+PvJ8CDYtEs1ipDmPorQ+" crossorigin="anonymous">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato:100,300,400,700">

    <!-- Styles -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
    {{-- <link href="{{ elixir('css/app.css') }}" rel="stylesheet"> --}}

    <style>
        body {
            font-family: 'Lato';
        }

        .fa-btn {
            margin-right: 6px;
        }
    </style>
</head>
<body id="app-layout">
    <nav class="navbar navbar-default navbar-static-top">
        <div class="container">
            <div class="navbar-header">

                <!-- Collapsed Hamburger -->
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                    <span class="sr-only">Toggle Navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>

                <!-- Branding Image -->
                <a class="navbar-brand" href="{{ url('/') }}">
                    Laravel
                </a>
            </div>
  <div class="collapse navbar-collapse" id="app-navbar-collapse">


                 <ul class="nav navbar-nav">
                    <li><a href="{{ url('/about') }}">About Myself</a></li>
                 </ul>

                  <ul class="nav navbar-nav">
                    <li><a href="{{ url('/subject') }}">My Subjects</a></li>
                  </ul>

                   <ul class="nav navbar-nav">
                    <li><a href="{{ url('/media') }}">My Social Media Accounts</a></li>
                   </ul>

                    <ul class="nav navbar-nav">
                    <li><a href="{{ url('/educ') }}">Educational Background</a></li>
                    </ul>

                     <ul class="nav navbar-nav">
                    <li><a href="{{ url('/php2') }}">About PHP2 Subject</a></li>
                    </ul>
                </div>
                 <!-- Right Side Of Navbar -->
                <ul class="nav navbar-nav navbar-right">
                    <!-- Authentication Links -->
                    @if (Auth::guest())
                        <li><a href="{{ url('/login') }}">Login</a></li>
                        <li><a href="{{ url('/register') }}">Register</a></li>
                    @else
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                {{ Auth::user()->name }} <span class="caret"></span>
                            </a>

                            <ul class="dropdown-menu" role="menu">
                                <li><a href="{{ url('/logout') }}"><i class="fa fa-btn fa-sign-out"></i>Logout</a></li>
                            </ul>
                        </li>
                    @endif
                </ul>
            </div>
        </div>
    </nav>

    @yield('content')


<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">So? Who's Christine Marie Plarisan by the way?</div>

                <div class="panel-body">
                   <p>
                        Well, Im the eldest daughter of Jerry and Marivic. Im a college student taking up a Bachelor of Science in Information Technology.
                        Next year will be my last year in the university, hopefully. I have two beautiful siblings, one annoying dog,
                        and three noisy kittens . I love to read books and write stories. I love to watch movies like action,lovestory,mystery and also cartoons.
                        Chocolates,takuyaki and shawarma serves as my comfort food. Everytime that Im pressured, not on the
                        mood and stressed I just simply eat one of the three food and it will make me feel better. In terms of school,
                        Im not good in academics unlike before when I was still in elementary and high school, college is a little bit different.
                        All I can say that college life is your road to reality. Aside from being a student Im also one of the member
                        of a student organization in this university. Most of the things we've done are attending seminars about leadership, organizing school
                        events and etc.I was a very shy type of person before but because of this organization and the people around me it helps me to build my
                        self-esteem and confident. I also tried a part-time job before but it didnt long last. Im an easily get bored person. Im an introvert,
                        i just keep things on my own. I love dark colors. Im also a girly sometimes , and most of the time boyish type of person.
                        I want to travel after I finished my studies. I want to help my family. I took up this course because before I was fascinated with 
                        gadgets, computers and laptops but its the Expectation vs. Reality.
                   </p>
                </div>
            </div>
        </div>
    </div>
</div>
 <!-- JavaScripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.3/jquery.min.js" integrity="sha384-I6F5OKECLVtK/BL+8iSLDEHowSAfUo76ZL9+kGAgTRdiByINKJaqTPH/QVNS1VDb" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
    {{-- <script src="{{ elixir('js/app.js') }}"></script> --}}
</body>
</html>


